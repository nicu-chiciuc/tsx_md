# @samebase/menger-sponge

An interactive Menger sponge for React. It ray-marches the sponge on the GPU with
[TypeGPU](https://typegpu.com). Drag rotates it, and the pointer opens deeper levels of the fractal
under it.

## Install

```sh
npm install @samebase/menger-sponge
```

React 19 is a peer dependency. The package already contains the TypeGPU build transform, so your
bundler needs no TypeGPU plugin. It needs no CSS either.

## Usage

The scene loads TypeGPU, so import it dynamically. The `settings` entry holds the defaults and types
and does not load TypeGPU.

```tsx
import {
  LOGO_PRESENTATION_TILT_DEFAULT_RADIUS_SCALE,
  LOGO_PRESENTATION_TILT_DEFAULT_STRENGTH_SCALE,
  MENGER_AUTOMATIC_PROBE_DEFAULT_SETTINGS,
  MENGER_HOVER_DEFAULT_REVEAL_RADIUS,
  MENGER_TYPE_GPU_DEFAULT_ANTIALIASING,
  MENGER_TYPE_GPU_DEFAULT_DEPTH,
  type LogoViewState,
} from "@samebase/menger-sponge/settings";
import { lazy, Suspense, useState } from "react";

const MengerSponge = lazy(() =>
  import("@samebase/menger-sponge").then((module) => ({ default: module.MengerSponge })),
);

export function Sponge({ fallbackSrc }: { fallbackSrc: string }) {
  const [view, setView] = useState<LogoViewState>({ elevationDegrees: 30, rotationDegrees: 40 });
  return (
    <div style={{ height: 480, width: 480 }}>
      <Suspense fallback={null}>
        <MengerSponge
          antialiasing={MENGER_TYPE_GPU_DEFAULT_ANTIALIASING}
          automaticProbe={{ ...MENGER_AUTOMATIC_PROBE_DEFAULT_SETTINGS, enabled: false }}
          backgroundColor="#ffffff"
          cameraFrustumPadding={1}
          depth={MENGER_TYPE_GPU_DEFAULT_DEPTH}
          elevationDegrees={view.elevationDegrees}
          faceColors={{ left: "#3b82f6", right: "#1d4ed8", top: "#93c5fd" }}
          fallbackSrc={fallbackSrc}
          onInteractionEnd={setView}
          onRenderUnavailable={() => {}}
          onViewChange={setView}
          pointerTiltEnabled
          pointerTiltRadiusScale={LOGO_PRESENTATION_TILT_DEFAULT_RADIUS_SCALE}
          pointerTiltStrengthScale={LOGO_PRESENTATION_TILT_DEFAULT_STRENGTH_SCALE}
          performanceMeasurementEnabled={false}
          resolutionScale={1}
          revealRadius={MENGER_HOVER_DEFAULT_REVEAL_RADIUS}
          rotationDegrees={view.rotationDegrees}
          viewDragConfig={undefined}
        />
      </Suspense>
    </div>
  );
}
```

The scene fills its parent, so give the parent a size. Colors are hex strings.

## WebGPU

The scene needs WebGPU. Until WebGPU is ready, and in browsers without it, the scene shows the
`fallbackSrc` image and calls `onRenderUnavailable` if WebGPU cannot start.

## License

Apache-2.0
