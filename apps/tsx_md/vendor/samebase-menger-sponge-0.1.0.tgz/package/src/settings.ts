// No import of typegpu or the scene here: a consumer loads the scene with a dynamic import and
// reads these values in its first chunk.
export {
  LOGO_PRESENTATION_TILT_DEFAULT_RADIUS_SCALE,
  LOGO_PRESENTATION_TILT_DEFAULT_STRENGTH_SCALE,
} from "@samebase/logo-model/logo-presentation-tilt";
export { type LogoViewDragConfig, type LogoViewState } from "@samebase/logo-model/logo-view-drag";
export {
  MENGER_AUTOMATIC_PROBE_DEFAULT_SETTINGS,
  type MengerAutomaticProbeMotionSettings,
} from "@samebase/logo-model/menger-automatic-probe";
export { MENGER_HOVER_DEFAULT_REVEAL_RADIUS } from "@samebase/logo-model/menger-hover";
export {
  MENGER_TYPE_GPU_DEFAULT_ANTIALIASING,
  MENGER_TYPE_GPU_DEFAULT_DEPTH,
  type MengerTypeGpuAntialiasing,
} from "@samebase/logo-model/menger-type-gpu-settings";

export type HexColor = `#${string}`;
